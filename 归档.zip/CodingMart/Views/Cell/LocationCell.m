//
//  LocationCell.m
//  CodingMart
//
//  Created by Ease on 15/11/3.
//  Copyright © 2015年 net.coding. All rights reserved.
//

#import "LocationCell.h"

@implementation LocationCell

@end
