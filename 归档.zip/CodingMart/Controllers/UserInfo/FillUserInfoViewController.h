//
//  FillUserInfoViewController.h
//  CodingMart
//
//  Created by Ease on 15/10/28.
//  Copyright © 2015年 net.coding. All rights reserved.
//

#import "BaseTableViewController.h"
#import "FillUserInfo.h"

@interface FillUserInfoViewController : BaseTableViewController
@end
