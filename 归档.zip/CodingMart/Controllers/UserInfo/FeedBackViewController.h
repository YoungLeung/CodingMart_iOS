//
//  FeedBackViewController.h
//  CodingMart
//
//  Created by Ease on 15/10/11.
//  Copyright © 2015年 net.coding. All rights reserved.
//

#import "BaseTableViewController.h"

@interface FeedBackViewController : BaseTableViewController

@end
