//
//  CodingMarkTestViewController.h
//  CodingMart
//
//  Created by HuiYang on 15/11/10.
//  Copyright © 2015年 net.coding. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WPHotspotLabel.h"

@interface CodingMarkTestViewController : BaseViewController


@end
