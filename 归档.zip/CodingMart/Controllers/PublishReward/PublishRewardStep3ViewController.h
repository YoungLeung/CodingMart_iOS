//
//  PublishRewardStep3ViewController.h
//  CodingMart
//
//  Created by Ease on 15/10/10.
//  Copyright © 2015年 net.coding. All rights reserved.
//

#import "BaseTableViewController.h"
#import "Reward.h"

@interface PublishRewardStep3ViewController : BaseTableViewController
@property (strong, nonatomic) Reward *rewardToBePublished;

@end
