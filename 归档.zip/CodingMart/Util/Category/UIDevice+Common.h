//
//  UIDevice+Common.h
//  CodingMart
//
//  Created by Ease on 15/11/6.
//  Copyright © 2015年 net.coding. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIDevice (Common)
+ (BOOL)isAllowedNotification;
+ (BOOL)isSystemVersioniOS8;
@end
