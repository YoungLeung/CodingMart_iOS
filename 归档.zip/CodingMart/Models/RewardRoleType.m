//
//  RewardRoleType.m
//  CodingMart
//
//  Created by Ease on 15/10/9.
//  Copyright © 2015年 net.coding. All rights reserved.
//

#import "RewardRoleType.h"

@implementation RewardRoleType

@end
