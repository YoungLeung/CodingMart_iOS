//
//  VerifiedInfo.m
//  CodingMart
//
//  Created by Ease on 15/11/3.
//  Copyright © 2015年 net.coding. All rights reserved.
//

#import "VerifiedInfo.h"

@implementation VerifiedInfo

@end
