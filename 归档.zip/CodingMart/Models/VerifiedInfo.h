//
//  VerifiedInfo.h
//  CodingMart
//
//  Created by Ease on 15/11/3.
//  Copyright © 2015年 net.coding. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VerifiedInfo : NSObject
@property (strong, nonatomic) NSNumber *userinfo, *skills, *identity, *survey;
@end
