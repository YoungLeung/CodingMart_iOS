//
//  RewardDetail.m
//  CodingMart
//
//  Created by Ease on 15/11/4.
//  Copyright © 2015年 net.coding. All rights reserved.
//

#import "RewardDetail.h"

@implementation RewardDetail
- (instancetype)init
{
    self = [super init];
    if (self) {
        _joinStatus = @(-1);
    }
    return self;
}

//- (Reward *)reward{
//    return nil;
//}
@end

@implementation TempC


@end