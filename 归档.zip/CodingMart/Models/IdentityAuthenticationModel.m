//
//  IdentityAuthenticationModel.m
//  CodingMart
//
//  Created by HuiYang on 15/11/18.
//  Copyright © 2015年 net.coding. All rights reserved.
//

#import "IdentityAuthenticationModel.h"
#import "DCKeyValueObjectMapping.h"

#define kLocalModelKey @"kLocalModelKey"

static 

@interface IdentityAuthenticationModel ()
@property(nonatomic,strong)NSMutableDictionary *localCache;

@end

@implementation IdentityAuthenticationModel

-(id)initForlocalCache
{
    DCKeyValueObjectMapping *parser =[DCKeyValueObjectMapping mapperForClass:[IdentityAuthenticationModel class] ];
    
    self = [parser parseDictionary:[IdentityAuthenticationModel loadLocalCacheDic]];
    self.localCache=[IdentityAuthenticationModel loadLocalCacheDic];
   
    return self;
}


- (NSDictionary *)toParams
{
    NSMutableDictionary *params = @{}.mutableCopy;
    params[@"id"] = _id;
    params[@"identity"] = _identity;
    params[@"identity_img_auth"] = _identity_img_auth;
    params[@"identity_img_back"] = _identity_img_back;
    params[@"identity_img_front"] = _identity_img_front;
    params[@"name"] = _name;
    params[@"alipay"] = _alipay;
    return params;
}

+(NSMutableDictionary*)loadLocalCacheDic
{
    NSMutableDictionary *dic=nil;
    NSUserDefaults *df =[NSUserDefaults standardUserDefaults];
    if ([df objectForKey:kLocalModelKey])
    {
        //缓存存在
        dic=[NSMutableDictionary dictionaryWithDictionary:[df objectForKey:kLocalModelKey]];
    }else
    {
        dic=[[NSMutableDictionary alloc]init];
    }
    return dic;
}



-(void)updateLocalCache
{
    [[NSUserDefaults standardUserDefaults]setObject:self.localCache forKey:kLocalModelKey];
    
}

-(void)setId:(NSString *)id
{
    _id=id;
    if (id.length<1)
        return;
    
    [self.localCache setObject:id forKey:@"id"];
    [self updateLocalCache];
}

-(void)setIdentity:(NSString *)identity
{
    _identity =identity;
    if (identity.length<1)
        return;
    
    [self.localCache setObject:identity forKey:@"identity"];
    [self updateLocalCache];
}

-(void)setIdentity_img_auth:(NSString *)identity_img_auth
{
    _identity_img_auth=identity_img_auth;
    if (identity_img_auth.length<1)
        return;
    
    [self.localCache setObject:identity_img_auth forKey:@"identity_img_auth"];
    [self updateLocalCache];
}
-(void)setIdentity_img_back:(NSString *)identity_img_back
{
    _identity_img_back=identity_img_back;
    if (identity_img_back.length<1)
        return;
    
    [self.localCache setObject:identity_img_back forKey:@"identity_img_back"];
    [self updateLocalCache];
}
-(void)setIdentity_img_front:(NSString *)identity_img_front
{
    _identity_img_front=identity_img_front;
    if (identity_img_front.length<1)
        return;
    
    [self.localCache setObject:identity_img_front forKey:@"identity_img_front"];
    [self updateLocalCache];
}
-(void)setName:(NSString *)name
{
    _name=name;
    
    if (name.length<1)
        return;
    
    [self.localCache setObject:name forKey:@"name"];
    [self updateLocalCache];
}
-(void)setAlipay:(NSString *)alipay
{
    _alipay=alipay;
    if (alipay.length<1)
        return;
    
    [self.localCache setObject:alipay forKey:@"alipay"];
    [self updateLocalCache];
}

@end
